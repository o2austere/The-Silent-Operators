'use client';

import SilentOperators from './SilentOperators';

export default function Home() {
  return <SilentOperators />;
}
