import './globals.css';

export const metadata = {
  title: 'Silent Operators — Intelligence System',
  description: 'The system sees what you refuse to.',
};

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
